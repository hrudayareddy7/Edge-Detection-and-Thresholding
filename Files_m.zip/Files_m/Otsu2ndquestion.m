function varargout = Otsu2ndquestion(varargin)
% OTSU2NDQUESTION MATLAB code for Otsu2ndquestion.fig
%      OTSU2NDQUESTION, by itself, creates a new OTSU2NDQUESTION or raises the existing
%      singleton*.
%
%      H = OTSU2NDQUESTION returns the handle to a new OTSU2NDQUESTION or the handle to
%      the existing singleton*.
%
%      OTSU2NDQUESTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OTSU2NDQUESTION.M with the given input arguments.
%
%      OTSU2NDQUESTION('Property','Value',...) creates a new OTSU2NDQUESTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Otsu2ndquestion_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Otsu2ndquestion_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Otsu2ndquestion

% Last Modified by GUIDE v2.5 21-Nov-2022 21:39:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Otsu2ndquestion_OpeningFcn, ...
                   'gui_OutputFcn',  @Otsu2ndquestion_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Otsu2ndquestion is made visible.
function Otsu2ndquestion_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Otsu2ndquestion (see VARARGIN)

% Choose default command line output for Otsu2ndquestion
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Otsu2ndquestion wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Otsu2ndquestion_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global image img_raw;
format long g;
format compact;
fontSize = 20;

% Check that user has the Image Processing Toolbox installed.
hasIPT = license('test', 'image_toolbox');
if ~hasIPT
	% User does not have the toolbox installed.
	message = sprintf('Sorry, but you do not seem to have the Image Processing Toolbox.\nDo you want to try to continue anyway?');
	reply = questdlg(message, 'Toolbox missing', 'Yes', 'No', 'Yes');
	if strcmpi(reply, 'No')
		% User said No, so exit.
		return;
	end
end

% Read in a standard MATLAB gray scale demo image.
folder = fullfile(matlabroot, '\toolbox\images\imdemos'); % Determine where demo folder is (works with R2013b and earlier)
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
button = menu('Use which demo image?', 'CameraMan', 'Moon', 'Eight', 'Coins', 'Pout');
if button == 1
	baseFileName = 'cameraman.tif';
elseif button == 2
	baseFileName = 'moon.tif';
elseif button == 3
	baseFileName = 'eight.tif';
elseif button == 4
	baseFileName = 'coins.png';
else
	baseFileName = 'pout.tif';
end

%===============================================================================
% Read in a standard MATLAB gray scale demo image.
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
% Get the full filename, with path prepended.
fullFileName = fullfile(folder, baseFileName);
% Check if file exists.
if ~exist(fullFileName, 'file')
	% File doesn't exist -- didn't find it there.  Check the search path for it.
	fullFileNameOnSearchPath = baseFileName; % No path this time.
	if ~exist(fullFileNameOnSearchPath, 'file')
		% Still didn't find it.  Alert user.
		errorMessage = sprintf('Error: %s does not exist in the search path folders.', fullFileName);
		uiwait(warndlg(errorMessage));
		return;
	end
end
grayImage = imread(fullFileName);

image = im2double(grayImage);
img_raw = image;   
axes(handles.axes1);
imshow(image);axis on;


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Multiple Thresholds
global image img_raw;
splits = 2;                        % # thresholds to split on
thresh = multithresh(image, splits);  % multi-level Otsu's Method 
image = imquantize(image, thresh); 
image = image - 1;
image = image ./ splits;                % scale between 0 and 1
axes(handles.axes2);

 imshowpair(img_raw,image,'montage')
title_str = strcat("Raw Image (left), Multi-Level Otsu with ",...
    num2str(splits), " Thresholds (right)"); pause(0.3)
title(title_str);


% --- Executes on button press in back_to_home.
function back_to_home_Callback(hObject, eventdata, handles)
% hObject    handle to back_to_home (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main;
closereq();