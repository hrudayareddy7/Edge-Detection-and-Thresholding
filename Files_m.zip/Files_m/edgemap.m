function varargout = edgemap(varargin)
% EDGEMAP MATLAB code for edgemap.fig
%      EDGEMAP, by itself, creates a new EDGEMAP or raises the existing
%      singleton*.
%
%      H = EDGEMAP returns the handle to a new EDGEMAP or the handle to
%      the existing singleton*.
%
%      EDGEMAP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EDGEMAP.M with the given input arguments.
%
%      EDGEMAP('Property','Value',...) creates a new EDGEMAP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before edgemap_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to edgemap_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help edgemap

% Last Modified by GUIDE v2.5 22-Nov-2022 17:42:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @edgemap_OpeningFcn, ...
                   'gui_OutputFcn',  @edgemap_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before edgemap is made visible.
function edgemap_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to edgemap (see VARARGIN)

% Choose default command line output for edgemap
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes edgemap wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = edgemap_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in original_image.
function original_image_Callback(hObject, eventdata, handles)
% hObject    handle to original_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of original_image
global image;
format long g;
format compact;
fontSize = 20;

% Check that user has the Image Processing Toolbox installed.
hasIPT = license('test', 'image_toolbox');
if ~hasIPT
	% User does not have the toolbox installed.
	message = sprintf('Sorry, but you do not seem to have the Image Processing Toolbox.\nDo you want to try to continue anyway?');
	reply = questdlg(message, 'Toolbox missing', 'Yes', 'No', 'Yes');
	if strcmpi(reply, 'No')
		% User said No, so exit.
		return;
	end
end

% Read in a standard MATLAB gray scale demo image.
folder = fullfile(matlabroot, '\toolbox\images\imdemos'); % Determine where demo folder is (works with R2013b and earlier)
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
button = menu('Use which demo image?', 'CameraMan', 'Moon', 'Eight', 'Coins', 'Pout');
if button == 1
	baseFileName = 'cameraman.tif';
elseif button == 2
	baseFileName = 'moon.tif';
elseif button == 3
	baseFileName = 'eight.tif';
elseif button == 4
	baseFileName = 'coins.png';
else
	baseFileName = 'pout.tif';
end

%===============================================================================
% Read in a standard MATLAB gray scale demo image.
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
% Get the full filename, with path prepended.
fullFileName = fullfile(folder, baseFileName);
% Check if file exists.
if ~exist(fullFileName, 'file')
	% File doesn't exist -- didn't find it there.  Check the search path for it.
	fullFileNameOnSearchPath = baseFileName; % No path this time.
	if ~exist(fullFileNameOnSearchPath, 'file')
		% Still didn't find it.  Alert user.
		errorMessage = sprintf('Error: %s does not exist in the search path folders.', fullFileName);
		uiwait(warndlg(errorMessage));
		return;
	end
end
grayImage = imread(fullFileName);

image = im2double(grayImage);
axes(handles.axes1);
imshow(image);axis on;

% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton2
global binImage image;
%Calculating Histogram of an Image
[count,m] = imhist(image,16);
%Plotting the stem of Histogram
axes(handles.axes3);
stem(m,count)
Thresh = otsuthresh(count);
%Displaying Threshold of an Image using Otsu Method
disp('Threshold obtained by using Otsu method');
disp(Thresh);
Binary_Image = imbinarize(image,Thresh);


% Fill the binary Image with holes.
binImage = imfill(Binary_Image, 'holes');
axes(handles.axes5);
imshow(binImage, []);
title('Image with Binary holes filled');
axis on

% --- Executes on button press in togglebutton3.
function togglebutton3_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton3
global binaryImage image;
%Find the boundry of the Binary Image
boundry = bwboundaries(binaryImage);
%imshow(255-image, []);
binaryIMG = image;
binaryIMG(:) = 0;
axes(handles.axes4);
imshow(binaryIMG, []);
title('White boundaries lines with Black Image');
hold on
axis on
for kb = 1:length(boundry)

 threshBoundr=boundry{kb};
 x = threshBoundr(:, 2);
 y = threshBoundr(:, 1);
 %Plotting the image whith white boundry lines with black Images
 plot(x, y,'w-','LineWidth', 3);
end


% --- Executes on button press in back_to_home.
function back_to_home_Callback(hObject, eventdata, handles)
% hObject    handle to back_to_home (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main;
closereq();
