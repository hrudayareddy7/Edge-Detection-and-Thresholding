function varargout = question4(varargin)
% QUESTION4 MATLAB code for question4.fig
%      QUESTION4, by itself, creates a new QUESTION4 or raises the existing
%      singleton*.
%
%      H = QUESTION4 returns the handle to a new QUESTION4 or the handle to
%      the existing singleton*.
%
%      QUESTION4('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in QUESTION4.M with the given input arguments.
%
%      QUESTION4('Property','Value',...) creates a new QUESTION4 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before question4_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to question4_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help question4

% Last Modified by GUIDE v2.5 21-Nov-2022 21:49:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @question4_OpeningFcn, ...
                   'gui_OutputFcn',  @question4_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before question4 is made visible.
function question4_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to question4 (see VARARGIN)

% Choose default command line output for question4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes question4 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = question4_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in original_image.
function original_image_Callback(hObject, eventdata, handles)
% hObject    handle to original_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of original_image
global image grayImage;
format long g;
format compact;
fontSize = 20;

% Check that user has the Image Processing Toolbox installed.
hasIPT = license('test', 'image_toolbox');
if ~hasIPT
	% User does not have the toolbox installed.
	message = sprintf('Sorry, but you do not seem to have the Image Processing Toolbox.\nDo you want to try to continue anyway?');
	reply = questdlg(message, 'Toolbox missing', 'Yes', 'No', 'Yes');
	if strcmpi(reply, 'No')
		% User said No, so exit.
		return;
	end
end

% Read in a standard MATLAB gray scale demo image.
folder = fullfile(matlabroot, '\toolbox\images\imdemos'); % Determine where demo folder is (works with R2013b and earlier)
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
button = menu('Use which demo image?', 'CameraMan', 'Moon', 'Eight', 'Coins', 'Pout');
if button == 1
	baseFileName = 'cameraman.tif';
elseif button == 2
	baseFileName = 'moon.tif';
elseif button == 3
	baseFileName = 'eight.tif';
elseif button == 4
	baseFileName = 'coins.png';
else
	baseFileName = 'pout.tif';
end

%===============================================================================
% Read in a standard MATLAB gray scale demo image.
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
% Get the full filename, with path prepended.
fullFileName = fullfile(folder, baseFileName);
% Check if file exists.
if ~exist(fullFileName, 'file')
	% File doesn't exist -- didn't find it there.  Check the search path for it.
	fullFileNameOnSearchPath = baseFileName; % No path this time.
	if ~exist(fullFileNameOnSearchPath, 'file')
		% Still didn't find it.  Alert user.
		errorMessage = sprintf('Error: %s does not exist in the search path folders.', fullFileName);
		uiwait(warndlg(errorMessage));
		return;
	end
end
grayImage = imread(fullFileName);

image = im2double(grayImage);
axes(handles.axes1);
imshow(image);

% --- Executes on button press in multi_threshold.
function multi_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to multi_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of multi_threshold

global BinaryImage image;
%Compute the grey level of an Image
level = graylevel(image);
%Binarize the Image
BinaryImage = imbinarize(image,level);
%Performing 2-level Threshold of an Image using Otsu's Method
threshold = multithresh(image,2); 
disp(threshold);%Display the threshold value
seg_Image = imquantize(image,threshold); % Apply the thresholds to the segmented image
  axes(handles.axes2); 
imshow(seg_Image,[]); 

 title('Multi-threshold with Otsu Method ');
function [level, em] = graylevel(I)
if ~isempty(I)
  I = im2uint8(I(:));
  num_bins = 256;
  counts = imhist(I,num_bins);
  
  if nargout <= 1
      level = levelthreshold(counts);
  else
      [level,em] = levelthreshold(counts);
  end
else
  level = 0.0;
  em = 0;
end

function [t,em] = levelthreshold(count)
num_bins = numel(count);

count = double( count(:) );

p = count / sum(count);
omega = cumsum(p);
mu = cumsum(p .* (1:num_bins)');
mu_t = mu(end);

sigma_squared = (mu_t * omega - mu).^2 ./ (omega .* (1 - omega));


maximumvalue = max(sigma_squared);
isfinite_maxval = isfinite(maximumvalue);
if isfinite_maxval
    idx = mean(find(sigma_squared == maximumvalue));
    % Normalization of threshold
    t = (idx - 1) / (num_bins - 1);
else
    t = 0.0;
end

if nargout > 1
    if isfinite_maxval
        em = maximumvalue/(sum(p.*((1:num_bins).^2)') - mu_t^2);
    else
        em = 0;
    end
end


function two_dimensional_entropy_Callback(hObject, eventdata, handles)
% hObject    handle to two_dimensional_entropy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of two_dimensional_entropy
global BinaryImage ;
 axes(handles.axes3);
 imshow(BinaryImage);
 title('2d Entropy of an Image');


% --- Executes on button press in Histogram_2d.
function Histogram_2d_Callback(hObject, eventdata, handles)
% hObject    handle to Histogram_2d (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fontSize = 10;
global grayImage;
[rows, columns, numberOfColorBands] = size(grayImage);
windowWidth = 21;
kernel = ones(windowWidth)/windowWidth^2;
blurredImage = imfilter(grayImage, kernel);
hist2d = zeros(256, 256);
for row = 1 : rows
	for column = 1 : columns	
		index1 = grayImage(row, column);
		index2 = round(blurredImage(row, column));
		hist2d(index1, index2) = hist2d(index1, index2) + 1;
	end
end
% Display the original gray scale image.
axes(handles.axes4);
%imshow(hist2d, []);
surf(hist2d);
title('2D Histogram', 'FontSize', fontSize);
axis on;
xlim([0, 255]);
ylim([0, 255]);
axis square;


% --- Executes on button press in back_to_home.
function back_to_home_Callback(hObject, eventdata, handles)
% hObject    handle to back_to_home (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main;
closereq();