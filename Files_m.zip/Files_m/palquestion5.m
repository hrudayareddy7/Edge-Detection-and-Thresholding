function varargout = palquestion5(varargin)
% PALQUESTION5 MATLAB code for palquestion5.fig
%      PALQUESTION5, by itself, creates a new PALQUESTION5 or raises the existing
%      singleton*.
%
%      H = PALQUESTION5 returns the handle to a new PALQUESTION5 or the handle to
%      the existing singleton*.
%
%      PALQUESTION5('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PALQUESTION5.M with the given input arguments.
%
%      PALQUESTION5('Property','Value',...) creates a new PALQUESTION5 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before palquestion5_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to palquestion5_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help palquestion5

% Last Modified by GUIDE v2.5 23-Nov-2022 10:33:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @palquestion5_OpeningFcn, ...
                   'gui_OutputFcn',  @palquestion5_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before palquestion5 is made visible.
function palquestion5_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to palquestion5 (see VARARGIN)

% Choose default command line output for palquestion5
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes palquestion5 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = palquestion5_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in original_image.
function original_image_Callback(hObject, eventdata, handles)
% hObject    handle to original_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global image;
format long g;
format compact;
fontSize = 20;

% Check that user has the Image Processing Toolbox installed.
hasIPT = license('test', 'image_toolbox');
if ~hasIPT
	% User does not have the toolbox installed.
	message = sprintf('Sorry, but you do not seem to have the Image Processing Toolbox.\nDo you want to try to continue anyway?');
	reply = questdlg(message, 'Toolbox missing', 'Yes', 'No', 'Yes');
	if strcmpi(reply, 'No')
		% User said No, so exit.
		return;
	end
end

% Read in a standard MATLAB gray scale demo image.
folder = fullfile(matlabroot, '\toolbox\images\imdemos'); % Determine where demo folder is (works with R2013b and earlier)
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
button = menu('Use which demo image?', 'CameraMan', 'Moon', 'Eight', 'Coins', 'Pout');
if button == 1
	baseFileName = 'cameraman.tif';
elseif button == 2
	baseFileName = 'moon.tif';
elseif button == 3
	baseFileName = 'eight.tif';
elseif button == 4
	baseFileName = 'coins.png';
else
	baseFileName = 'pout.tif';
end

%===============================================================================
% Read in a standard MATLAB gray scale demo image.
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
% Get the full filename, with path prepended.
fullFileName = fullfile(folder, baseFileName);
% Check if file exists.
if ~exist(fullFileName, 'file')
	% File doesn't exist -- didn't find it there.  Check the search path for it.
	fullFileNameOnSearchPath = baseFileName; % No path this time.
	if ~exist(fullFileNameOnSearchPath, 'file')
		% Still didn't find it.  Alert user.
		errorMessage = sprintf('Error: %s does not exist in the search path folders.', fullFileName);
		uiwait(warndlg(errorMessage));
		return;
	end
end
grayImage = imread(fullFileName);

image = im2double(grayImage);
axes(handles.axes1);
imshow(image);axis on;;

% --- Executes on button press in histogram.
function histogram_Callback(hObject, eventdata, handles)
% hObject    handle to histogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global image;
[counts,x] = imhist(image,16);
axes(handles.axes2);
stem(x,counts)

T = otsuthresh(counts);
set(handles.edit_Otsu,'string',num2str(T))
% --- Executes on button press in grey_level.
function grey_level_Callback(hObject, eventdata, handles)
% hObject    handle to grey_level (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global image L;
global PtA PtB PtC PtD PA PB PC PD;
offsets = [0 1;-1 1;-1 0;-1 -1];
[glcms,SI] = graycomatrix(image,'Offset',[2 0],'Symmetric', true);
glcms;
newIMG=rescale(SI);
axes(handles.axes3);
imshow(newIMG);
title('Gray-level');
%Normalizing the total number of transitions in the co-occyrence matrix,a
%desired transition probalitiy from grey level i to grey level j is obained
%by
t=glcms;
L =length(t)-1;
for i =1:size(t,1)
    for j =1:size(t,2)
        tkI = 0;
        for k = 1:L
            for I = 1:L
               tkI = tkI + t(k,I) ;
            end
        end
        P(i,j) = t(i,j)/tkI;
    end
end

%Quadrants of the Co-Occurence Matrix
t= 4; %0<=t<=L-1
%For PA
for i=1:t
    for j=1:t
        PA(i,j)=P(i,j);
    end
end

%For PB
for i=1:t
    for j=t+1:L
        PB(i,j)=P(i,j);
    end
end

%For PC
for i=t+1:L
    for j=1:t
        PC(i,j)=P(i,j);
    end
end

%For PD
for i=t+1:L
    for j=t+1:L
        PD(i,j)=P(i,j);
    end
end

PA(isnan(PA))=0;
PB(isnan(PB))=0;
PC(isnan(PC))=0;
PD(isnan(PD))=0;

PPA=sum(sum(PA));
PPB=sum(sum(PB));
PPC=sum(sum(PC));
PPD=sum(sum(PD));
% fprintf('The probablitiy associated with Quadrant A is %f\n',PPA);
% fprintf('The probablitiy associated with Quadrant B is %f\n',PPB);
% fprintf('The probablitiy associated with Quadrant C is %f\n',PPC);
% fprintf('The probablitiy associated with Quadrant D is %f\n',PPD);
%disp('The probablitiy associated with Quadrant A',PPA);
% disp('The probablitiy associated with Quadrant B',PPB);
% disp('The probablitiy associated with Quadrant C',PPC);
% disp('The probablitiy associated with Quadrant D',PPD);
% set(handles.PAt1,'string',num2str(PPA));
% set(handles.PBt1,'string',num2str(PPB));
% set(handles.PCt1,'string',num2str(PPC));
% set(handles.PDt1,'string',num2str(PPD));
%The probabilities of grey-level transiton within each particular quadrant
%can be further obtained by so called cell probabalities
PA = normalize(PA);
PB = normalize(PB);
PC = normalize(PC);
PD = normalize(PD);

PA(isnan(PA))=0;
PB(isnan(PB))=0;
PC(isnan(PC))=0;
PD(isnan(PD))=0;

%PtA = sum(sum(P)) / sum(sum(PA))
for i=1:t
    for j=1:t
        PtA(i,j) = P(i,j)/PA(i,j);
    end
end

%For PB
for i=1:t
    for j=t+1:L
        PtB(i,j) = P(i,j)/PB(i,j);
    end
end

%For PC
for i=t+1:L
    for j=1:t
        PtC(i,j) = P(i,j)/PC(i,j);
    end
end

%For PD
for i=t+1:L
    for j=t+1:L
        PtD(i,j) = P(i,j)/PD(i,j);
    end
end
% disp('The probability of grey-level transition with Quadrant A is');
% disp(PtA);
% disp('The probability of grey-level transition with Quadrant B is');
% disp(PtB);
% disp('The probability of grey-level transition with Quadrant C is');
% disp(PtC);
% disp('The probability of grey-level transition with Quadrant D is');
% disp(PtD);
% --- Executes on button press in local_entropy.
function local_entropy_Callback(hObject, eventdata, handles)
% hObject    handle to local_entropy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%for HBB 
global PtA PtB PtC PtD L image PA PB PC PD;
t= 4; %0<=t<=L-1

% 
% 
% BW = imbinarize(image, abs(mean(real(sum(HLE)),'all')));
% x=abs(real(HLE));
% set(handles.hbbt,'string',num2str(real(HBB)));
% 
% set(handles.hff_t,'string',num2str(real(HFF)));
% 
% set(handles.hle_t,'string',num2str(abs(real(HLE))));
% 
% set(handles.tLE,'string',num2str(abs(mean(real(sum(HLE))))));
% axes(handles.axes4);
% imshow(BW);
% title('Local Entropy thrsh');
%for HBB 
for i=1:t
    for j=1:t
        HBB(i,j)=PtA(i,j) * log(PtA(i,j));
    end
end
HBB=-sum(HBB);
%for HFF 
for i=t+1:L
    for j=1:t
        HFF(i,j)=PtC(i,j) * log(PtC(i,j));
    end
end
HFF=-sum(HFF);
HBB(isnan(HBB))=0;
HFF(isnan(HFF))=0;
%disp('The HBB(t) is');
disp(HBB);
%disp('The HFF(t) is');
disp(HFF);

HLE = HBB + HFF;
%disp('The HLE(t) is');
disp(HLE);

HLE(isnan(HLE))=0;

BW = imbinarize(image, abs(mean(real(sum(HLE)),'all')));
 axes(handles.axes4);
imshow(BW);
title('The image with Local Entropy threshold');
x=abs(mean(real(sum(HLE))));
set(handles.tLE,'string',num2str(uint8(x*255)));

% --- Executes on button press in global_entropy.
function global_entropy_Callback(hObject, eventdata, handles)
% hObject    handle to global_entropy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%for HFB 
global PtA PtB PtC PtD L image PA PB PC PD;
t=4;
PtD=normalize(PtD);
PtB=normalize(PtB);
PB(isnan(PB))=0;
PD(isnan(PD))=0;
for i=1:t
    for j=t+1:L
        HFB(i,j)=PtB(i,j) * log(PtB(i,j));
    end
end

HFB=-sum(HFB);

%for HBF 
for i=t+1:L
    for j=t+1:L
        HBF(i,j)=PtD(i,j) * log(PtD(i,j));
    end
end
HBF(isnan(HBF))=0;

HBF=-sum(HBF);

disp('The HFB(t) is');
disp(HFB);
 disp('The HBF(t) is');
 disp(HBF);


HJE = HFB+ HBF;
% disp('The HJE(t) is');
% disp(HJE);
BW = imbinarize(image, abs(mean(real(HJE),'all')));
axes(handles.axes5);
imshow(BW);
title('Joint Entropy Image');
x=abs(mean(real(sum(HJE))));
set(handles.hje_t,'string',num2str(uint8(x*255)));

function otsu_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to otsu_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of otsu_threshold as text
%        str2double(get(hObject,'String')) returns contents of otsu_threshold as a double


% --- Executes during object creation, after setting all properties.
function otsu_threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to otsu_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_Otsu_Callback(hObject, eventdata, handles)
% hObject    handle to edit_Otsu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_Otsu as text
%        str2double(get(hObject,'String')) returns contents of edit_Otsu as a double


% --- Executes during object creation, after setting all properties.
function edit_Otsu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_Otsu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PAt1_Callback(hObject, eventdata, handles)
% hObject    handle to PAt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PAt1 as text
%        str2double(get(hObject,'String')) returns contents of PAt1 as a double


% --- Executes during object creation, after setting all properties.
function PAt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PAt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PBt1_Callback(hObject, eventdata, handles)
% hObject    handle to PBt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PBt1 as text
%        str2double(get(hObject,'String')) returns contents of PBt1 as a double


% --- Executes during object creation, after setting all properties.
function PBt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PBt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PCt1_Callback(hObject, eventdata, handles)
% hObject    handle to PCt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PCt1 as text
%        str2double(get(hObject,'String')) returns contents of PCt1 as a double


% --- Executes during object creation, after setting all properties.
function PCt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PCt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PDt1_Callback(hObject, eventdata, handles)
% hObject    handle to PDt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PDt1 as text
%        str2double(get(hObject,'String')) returns contents of PDt1 as a double


% --- Executes during object creation, after setting all properties.
function PDt1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PDt1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function hbbt_Callback(hObject, eventdata, handles)
% hObject    handle to hbbt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hbbt as text
%        str2double(get(hObject,'String')) returns contents of hbbt as a double


% --- Executes during object creation, after setting all properties.
function hbbt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hbbt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function hff_t_Callback(hObject, eventdata, handles)
% hObject    handle to hff_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hff_t as text
%        str2double(get(hObject,'String')) returns contents of hff_t as a double


% --- Executes during object creation, after setting all properties.
function hff_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hff_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function hle_t_Callback(hObject, eventdata, handles)
% hObject    handle to hle_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hle_t as text
%        str2double(get(hObject,'String')) returns contents of hle_t as a double


% --- Executes during object creation, after setting all properties.
function hle_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hle_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tLE_Callback(hObject, eventdata, handles)
% hObject    handle to tLE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tLE as text
%        str2double(get(hObject,'String')) returns contents of tLE as a double


% --- Executes during object creation, after setting all properties.
function tLE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tLE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in back_to_home.
function back_to_home_Callback(hObject, eventdata, handles)
% hObject    handle to back_to_home (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main;
closereq();



function hje_t_Callback(hObject, eventdata, handles)
% hObject    handle to hje_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hje_t as text
%        str2double(get(hObject,'String')) returns contents of hje_t as a double


% --- Executes during object creation, after setting all properties.
function hje_t_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hje_t (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
