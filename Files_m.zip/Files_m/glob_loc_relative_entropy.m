function varargout = glob_loc_relative_entropy(varargin)
% GLOB_LOC_RELATIVE_ENTROPY MATLAB code for glob_loc_relative_entropy.fig
%      GLOB_LOC_RELATIVE_ENTROPY, by itself, creates a new GLOB_LOC_RELATIVE_ENTROPY or raises the existing
%      singleton*.
%
%      H = GLOB_LOC_RELATIVE_ENTROPY returns the handle to a new GLOB_LOC_RELATIVE_ENTROPY or the handle to
%      the existing singleton*.
%
%      GLOB_LOC_RELATIVE_ENTROPY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GLOB_LOC_RELATIVE_ENTROPY.M with the given input arguments.
%
%      GLOB_LOC_RELATIVE_ENTROPY('Property','Value',...) creates a new GLOB_LOC_RELATIVE_ENTROPY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before glob_loc_relative_entropy_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to glob_loc_relative_entropy_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help glob_loc_relative_entropy

% Last Modified by GUIDE v2.5 23-Nov-2022 14:10:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @glob_loc_relative_entropy_OpeningFcn, ...
                   'gui_OutputFcn',  @glob_loc_relative_entropy_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before glob_loc_relative_entropy is made visible.
function glob_loc_relative_entropy_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to glob_loc_relative_entropy (see VARARGIN)

% Choose default command line output for glob_loc_relative_entropy
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes glob_loc_relative_entropy wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = glob_loc_relative_entropy_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global image grayImage;
format long g;
format compact;
fontSize = 20;

% Check that user has the Image Processing Toolbox installed.
hasIPT = license('test', 'image_toolbox');
if ~hasIPT
	% User does not have the toolbox installed.
	message = sprintf('Sorry, but you do not seem to have the Image Processing Toolbox.\nDo you want to try to continue anyway?');
	reply = questdlg(message, 'Toolbox missing', 'Yes', 'No', 'Yes');
	if strcmpi(reply, 'No')
		% User said No, so exit.
		return;
	end
end

% Read in a standard MATLAB gray scale demo image.
folder = fullfile(matlabroot, '\toolbox\images\imdemos'); % Determine where demo folder is (works with R2013b and earlier)
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
button = menu('Use which demo image?', 'CameraMan', 'Moon', 'Eight', 'Coins', 'Pout');
if button == 1
	baseFileName = 'cameraman.tif';
elseif button == 2
	baseFileName = 'moon.tif';
elseif button == 3
	baseFileName = 'eight.tif';
elseif button == 4
	baseFileName = 'coins.png';
else
	baseFileName = 'pout.tif';
end

%===============================================================================
% Read in a standard MATLAB gray scale demo image.
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
% Get the full filename, with path prepended.
fullFileName = fullfile(folder, baseFileName);
% Check if file exists.
if ~exist(fullFileName, 'file')
	% File doesn't exist -- didn't find it there.  Check the search path for it.
	fullFileNameOnSearchPath = baseFileName; % No path this time.
	if ~exist(fullFileNameOnSearchPath, 'file')
		% Still didn't find it.  Alert user.
		errorMessage = sprintf('Error: %s does not exist in the search path folders.', fullFileName);
		uiwait(warndlg(errorMessage));
		return;
	end
end
image = imread(fullFileName);

axes(handles.axes1);
imshow(image);

% --- Executes on button press in local_entropy.
function local_entropy_Callback(hObject, eventdata, handles)
% hObject    handle to local_entropy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global image;
[yy, ITL] = Localentr(image);
axes(handles.axes2);
imshow(ITL) 

  set(handles.lrem, 'String', yy);
title('Local Relative Entropy Image');
% --- Executes on button press in joint_relative.
function joint_relative_Callback(hObject, eventdata, handles)
% hObject    handle to joint_relative (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global image;

NThresholds = 3;
for i=1:size(image,3)
    [ tJRE, cI(:,:,i)] = thresholdImage(image(:,:,i),NThresholds);
end
axes(handles.axes3);
        imshow(cI),title('Joint-Relative Entropy Image');
        
        
      set(handles.jrem, 'String', num2str(uint8(tJRE(2))));
        %set(JRentropyvalue, 'String', num2str(uint8(tJRE(2))));
 %disp(num2str(uint8(tJRE(2))));
axis off

% --- Executes on button press in global_entropy.
function global_entropy_Callback(hObject, eventdata, handles)
% hObject    handle to global_entropy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global image;
 [thrsh,ITG ]= globalentropie(image);
 axes(handles.axes4);
imshow(ITG)  ;

set(handles.grem, 'String', thrsh);

    title('Global Relative Entropy Image');
    %% Global Entropy
function [threshold I1]=globalentropie(I)
    [n,m]=size(I);
    h=imhist(I);
    %normalize the histogram ==>  hn(k)=h(k)/(n*m) ==> k  in [1 256]
    hn=h/(n*m);
   
    %Cumulative distribution function
	c(1) = hn(1);
    for l=2:256
        c(l)=c(l-1)+hn(l);
    end
    
    
    hl = zeros(1,256);
    hh = zeros(1,256);
    for t=1:256
        %low range entropy
        cl=double(c(t));
        if cl>0
            for i=1:t
                if hn(i)>0
                    hl(t) = hl(t)- (hn(i)/cl)*log(hn(i)/cl);                      
                end
            end
        end
        
        %high range entropy
        ch=double(1.0-cl);  %constraint cl+ch=1
        if ch>0
            for i=t+1:256
                if hn(i)>0
                    hh(t) = hh(t)- (hn(i)/ch)*log(hn(i)/ch);
                end
            end
        end
    end
    
    % choose best threshold
    
	h_max =hl(1)+hh(1);
	threshold = 0;
    entropie(1)=h_max;
    for t=2:256
        entropie(t)=hl(t)+hh(t);
        if entropie(t)>h_max
            h_max=entropie(t);
            threshold=t-1;
        end
    end
    
    % Display    
    I1 = zeros(size(I));
    I1(I<threshold) = 0;
    I1(I>threshold) = 255;

    
    %% Local Entropy
    
    function [threshold I1]=Localentr(I)
    h=imhist(I);
    [n,m]=size(I);
    %normalize the histogram ==>  hn(k)=h(k)/(n*m) ==> k  in [1 256]
    hn=h/(n*m);
    % entropy of gray level image
    imEntropy=double(0);
    for i=1:256
        imEntropy=double(imEntropy+(i*hn(i)*log(i)));
    end
    % MCE
    for t=1:256
        % moyenne de Low range image
        lowValue= 0;
        lowSum= 0;
        for i=1:t
            lowValue=lowValue+(i*hn(i));
            lowSum=lowSum+hn(i);
        end
        if lowSum>0
            lowValue=lowValue/lowSum;
        else
            lowValue=1;
        end
        % moyenne de High range image
        highValue= 0;
        highSum= 0;
        for i=t+1 : 256
            highValue=highValue+(i*hn(i));
            highSum=highSum+hn(i);
        end
        if highSum>0
            highValue=highValue/highSum;
        else
            highValue=1;
        end
        % Entropy of low range 
        lowEntropy=0;
        for i=1:t
            lowEntropy=lowEntropy+(i*hn(i)*log(lowValue));
        end      
        % Entropy of high range 
        highEntropy=0;
        for i=t+1 : 256
            highEntropy=highEntropy+(i*hn(i)*log(highValue));
        end
        % Cross Entropy 
        highEntropy;
        lowEntropy;
        imEntropy;
        CE(t)= imEntropy - lowEntropy - highEntropy; 
    end
    %
    % choose the best threshold
    D_min =CE(1);
    entropie(1)=D_min;
    threshold = 0;
    for t=2:256
        entropie(t)=CE(t);
        if entropie(t)<D_min
            D_min=entropie(t);
            threshold=t-1;
        end
    end
    %****************
    % Display    
    I1 = zeros(size(I));
    I1(I<threshold) = 0;
    I1(I>threshold) = 255;
    
  %% Thresholding image function
    function [Thresholds J]=thresholdImage(I,NThresholds)
if length(size(I))>2
    I=rgb2gray(I);
end
H = imhist(I);
h = H / numel(I);
NumberOfIter = 1;
FuzzyParameters = differentialEvolution(h,NThresholds,NumberOfIter);
Thresholds=mean([FuzzyParameters(1:2:end);FuzzyParameters(2:2:end)]);
if length(Thresholds)==1
    J=255*im2bw(I,Thresholds/255);
else
    X=grayslice(I,Thresholds);
    J=uint8(255*mat2gray(X));
end
J=uint8(round(J));
%% JR entropy
function entropy=JREntropy(x,h)

entropy=0;
x=[1 1 (x+1) 256 256];
for i=1:2:length(x)-3
    U=trapmf(1:256,x(i:i+3));
    P=U.*h;
    %P = p ./ numel(IMG);
    P(isnan(P))=0;
    LevelP = (P .* log(P./P'));
    entropy = mean(sum(LevelP));
end
entropy=-entropy;

%% evolution function
function T=differentialEvolution(h,NThresholds,max_runs)

D=NThresholds*2;
max_val=255;                         % Upper Limit of the search space for 8-bit images
min_val=0;                           % Lower Limit of the search space
range_min = min_val*ones(1,D);
range_max = max_val*ones(1,D);

NP = 10*D;                           % Population Size of DE
maxgen = 100;                        % No. of generations of DE
F = 0.5;                             % Weighting Factor
CR = 0.9;                            % Crossover probability
statistics_x = zeros(max_runs,D);
fitness_parent = zeros(1,NP);
fitness_child = zeros(1,NP);
x = zeros(NP,D);
w=waitbar(0,'Loading Image');
for runn = 1:max_runs
    
    for i = 1 : NP
        for j = 1:D
            x(i, j) =  round(range_min(j) + ((range_max(j)-range_min(j))*(rand)));
        end
        x(i,:)=sort(x(i,:));
        fitness_parent(i) = JREntropy(x(i,:),h');
    end
    
    v = zeros(size(x));
    u = zeros(size(x));

    for gen = 2:maxgen
        %waitbar(gen/maxgen,w,sprintf('%12.0f%s',gen/maxgen*100,'% DONE'));
        %*********************************************************************
        % Mutation
        %*********************************************************************
        for i = 1:NP
            r = ceil(rand(1,3)*NP);
            while r(1)==r(2) || r(2)== r(3) || min(r)==0 || max(r)>NP
                r = ceil(rand(1,3)*NP);
            end
            v(i,:) = x(r(1),:) + F*(x(r(2),:) - x(r(3),:));
            
            ra=round(rand*D);
            for j = 1:D
                if rand > CR || j==ra
                    u(i,j) = x(i,j);
                else
                    u(i,j) = v(i,j);
                end
            end
            u(i,:) = round(u(i,:));
            u(i,:)=sort(u(i,:));
        end
        
        for i = 1:NP
            for jj = 1:D
                u(i,jj) = max(u(i,jj), range_min(jj));
                u(i,jj) = min(u(i,jj), range_max(jj));
            end
            u(i,:)=sort(u(i,:));
            fitness_child(i,1) = JREntropy(u(i,:),h');
        end
        
        for i = 1:NP
            if fitness_parent(i) < fitness_child(i)
                fitness_parent(i) = fitness_child(i);
                x(i,:) = u(i,:);
            end
        end
        
        
        [~,globalbest_index] = max(fitness_parent);
        global_xbest = x(globalbest_index,:);
        
    end
    statistics_x(runn,:) = global_xbest;
end
if max_runs==1
    T =statistics_x;
else
    T = median(statistics_x);
end
close(w);



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function value_global_Callback(hObject, eventdata, handles)
% hObject    handle to value_global (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_global as text
%        str2double(get(hObject,'String')) returns contents of value_global as a double


% --- Executes during object creation, after setting all properties.
function value_global_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_global (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function relative_value_Callback(hObject, eventdata, handles)
% hObject    handle to relative_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of relative_value as text
%        str2double(get(hObject,'String')) returns contents of relative_value as a double


% --- Executes during object creation, after setting all properties.
function relative_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to relative_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lrem_Callback(hObject, eventdata, handles)
% hObject    handle to lrem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lrem as text
%        str2double(get(hObject,'String')) returns contents of lrem as a double


% --- Executes during object creation, after setting all properties.
function lrem_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lrem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function jrem_Callback(hObject, eventdata, handles)
% hObject    handle to jrem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of jrem as text
%        str2double(get(hObject,'String')) returns contents of jrem as a double


% --- Executes during object creation, after setting all properties.
function jrem_CreateFcn(hObject, eventdata, handles)
% hObject    handle to jrem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function grem_Callback(hObject, eventdata, handles)
% hObject    handle to grem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of grem as text
%        str2double(get(hObject,'String')) returns contents of grem as a double


% --- Executes during object creation, after setting all properties.
function grem_CreateFcn(hObject, eventdata, handles)
% hObject    handle to grem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in back_to_home.
function back_to_home_Callback(hObject, eventdata, handles)
% hObject    handle to back_to_home (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main;
closereq;