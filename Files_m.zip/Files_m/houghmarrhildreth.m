function varargout = houghmarrhildreth(varargin)
% HOUGHMARRHILDRETH MATLAB code for houghmarrhildreth.fig
%      HOUGHMARRHILDRETH, by itself, creates a new HOUGHMARRHILDRETH or raises the existing
%      singleton*.
%
%      H = HOUGHMARRHILDRETH returns the handle to a new HOUGHMARRHILDRETH or the handle to
%      the existing singleton*.
%
%      HOUGHMARRHILDRETH('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HOUGHMARRHILDRETH.M with the given input arguments.
%
%      HOUGHMARRHILDRETH('Property','Value',...) creates a new HOUGHMARRHILDRETH or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before houghmarrhildreth_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to houghmarrhildreth_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help houghmarrhildreth

% Last Modified by GUIDE v2.5 23-Nov-2022 12:07:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @houghmarrhildreth_OpeningFcn, ...
                   'gui_OutputFcn',  @houghmarrhildreth_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before houghmarrhildreth is made visible.
function houghmarrhildreth_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to houghmarrhildreth (see VARARGIN)

% Choose default command line output for houghmarrhildreth
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes houghmarrhildreth wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = houghmarrhildreth_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in original_image.
function original_image_Callback(hObject, eventdata, handles)
% hObject    handle to original_image (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% eventdata  reserved - to be defined in a future version of MATLAB
global image rotI;
format long g;
format compact;
fontSize = 20;

% Check that user has the Image Processing Toolbox installed.
hasIPT = license('test', 'image_toolbox');
if ~hasIPT
	% User does not have the toolbox installed.
	message = sprintf('Sorry, but you do not seem to have the Image Processing Toolbox.\nDo you want to try to continue anyway?');
	reply = questdlg(message, 'Toolbox missing', 'Yes', 'No', 'Yes');
	if strcmpi(reply, 'No')
		% User said No, so exit.
		return;
	end
end

% Read in a standard MATLAB gray scale demo image.
folder = fullfile(matlabroot, '\toolbox\images\imdemos'); % Determine where demo folder is (works with R2013b and earlier)
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
button = menu('Use which demo image?', 'CameraMan', 'Moon', 'Eight', 'Coins', 'Pout');
if button == 1
	baseFileName = 'cameraman.tif';
elseif button == 2
	baseFileName = 'moon.tif';
elseif button == 3
	baseFileName = 'eight.tif';
elseif button == 4
	baseFileName = 'coins.png';
else
	baseFileName = 'pout.tif';
end

%===============================================================================
% Read in a standard MATLAB gray scale demo image.
folder = fileparts(which('cameraman.tif')); % Determine where demo folder is (works with all versions).
% Get the full filename, with path prepended.
fullFileName = fullfile(folder, baseFileName);
% Check if file exists.
if ~exist(fullFileName, 'file')
	% File doesn't exist -- didn't find it there.  Check the search path for it.
	fullFileNameOnSearchPath = baseFileName; % No path this time.
	if ~exist(fullFileNameOnSearchPath, 'file')
		% Still didn't find it.  Alert user.
		errorMessage = sprintf('Error: %s does not exist in the search path folders.', fullFileName);
		uiwait(warndlg(errorMessage));
		return;
	end
end
grayImage = imread(fullFileName);
rotI = imrotate(grayImage,33,'crop');
image = im2double(grayImage);
axes(handles.axes1);
imshow(image);axis on;


% --- Executes on button press in marrhildreth.
function marrhildreth_Callback(hObject, eventdata, handles)
% hObject    handle to marrhildreth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ResThr image;
gfilter= [0 0 1 0 0;
       0 1 2 1 0;
       1 2 -16 2 1;
       0 1 2 1 0;
       0 0 1 0 0];
   
smIMG=conv2(image,gfilter);
% finding the Zero Crossings
[rr,cc]=size(smIMG);
zerocross=zeros([rr,cc]);
for i=2:rr-1
    for j=2:cc-1
        if (smIMG(i,j)>0)
             if (smIMG(i,j+1)>=0 && smIMG(i,j-1)<0) || (smIMG(i,j+1)<0 && smIMG(i,j-1)>=0)
                             
                zerocross(i,j)= smIMG(i,j+1);
                        
            elseif (smIMG(i+1,j)>=0 && smIMG(i-1,j)<0) || (smIMG(i+1,j)<0 && smIMG(i-1,j)>=0)
                    zerocross(i,j)= smIMG(i,j+1);
            elseif (smIMG(i+1,j+1)>=0 && smIMG(i-1,j-1)<0) || (smIMG(i+1,j+1)<0 && smIMG(i-1,j-1)>=0)
                  zerocross(i,j)= smIMG(i,j+1);
            elseif (smIMG(i-1,j+1)>=0 && smIMG(i+1,j-1)<0) || (smIMG(i-1,j+1)<0 && smIMG(i+1,j-1)>=0)
                  zerocross(i,j)=smIMG(i,j+1);
            end
                        
        end
            
    end
end
Res_i=im2uint8(zerocross);

% thresholding
ResThr= Res_i>110;

axes2 = findobj(0, 'tag', 'axes2');
axes(handles.axes2);
imshow(ResThr);title('Marr-Hildreth');
axis on;
%end Marr-Hildreth



% --- Executes on button press in hough_transform.
function hough_transform_Callback(hObject, eventdata, handles)
% hObject    handle to hough_transform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ResThr H theta rho P;
[H,theta,rho] = hough(ResThr);
axes(handles.axes3);
imshow(imadjust(rescale(H)),[],...
       'XData',theta,...
       'YData',rho,...
       'InitialMagnification','fit');
xlabel('\theta (degrees)')
ylabel('\rho')
axis on
axis normal 
hold on
colormap(gca,hot)

P = houghpeaks(H,5,'threshold',ceil(0.3*max(H(:))));

% --- Executes on button press in back_to_home.
function back_to_home_Callback(hObject, eventdata, handles)
% hObject    handle to back_to_home (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main;
closereq();


% --- Executes on button press in Hough_lines.
function Hough_lines_Callback(hObject, eventdata, handles)
% hObject    handle to Hough_lines (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ResThr H theta rho P  rotI;
lines = houghlines(ResThr,theta,rho,P,'FillGap',5,'MinLength',7);
axes(handles.axes4);
 imshow(rotI), hold on
max_len = 0;
for k = 1:length(lines)
   xy = [lines(k).point1; lines(k).point2];
   plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','green');

   % Plot beginnings and ends of lines
   plot(xy(1,1),xy(1,2),'x','LineWidth',2,'Color','yellow');
   plot(xy(2,1),xy(2,2),'x','LineWidth',2,'Color','red');

   % Determine the endpoints of the longest line segment
   len = norm(lines(k).point1 - lines(k).point2);
   if ( len > max_len)
      max_len = len;
      xy_long = xy;
   end
end
% highlight the longest line segment
plot(xy_long(:,1),xy_long(:,2),'LineWidth',2,'Color','red');

